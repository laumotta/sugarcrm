    <?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            '6.1.0'
          ),
          'acceptable_sugar_flavors' =>
          array(
            'CE', 'PRO','ENT'
          ),
          'readme'=>'',
          'key'=>'',
          'author' => '',
          'description' => '',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'mod_010111',
          'published_date' => '2011-01-06 19:29:37',
          'type' => 'module',
          'version' => '1294342177',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'mod_010111',
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/es_es.mod_010111.php',
      'to_module' => 'application',
      'language' => 'es_es',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/en_us.mod_010111.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Accounts/language/es_es.lang.php',
      'to_module' => 'Accounts',
      'language' => 'es_es',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/language/es_es.lang.php',
      'to_module' => 'Contacts',
      'language' => 'es_es',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Documents/language/es_es.lang.php',
      'to_module' => 'Documents',
      'language' => 'es_es',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Opportunities/language/es_es.lang.php',
      'to_module' => 'Opportunities',
      'language' => 'es_es',
    ),
  ),
  'custom_fields' => 
  array (
    'Accountstype_customer_c' => 
    array (
      'id' => 'Accountstype_customer_c',
      'name' => 'type_customer_c',
      'label' => 'LBL_TYPE_CUSTOMER',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '1',
      'default_value' => 'undefined',
      'date_modified' => '2011-01-04 19:45:27',
      'deleted' => '0',
      'audited' => '1',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'type_customer_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsrfc_c' => 
    array (
      'id' => 'Accountsrfc_c',
      'name' => 'rfc_c',
      'label' => 'LBL_RFC',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '13',
      'require_option' => '1',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 19:46:22',
      'deleted' => '0',
      'audited' => '1',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsdocuments_c' => 
    array (
      'id' => 'Accountsdocuments_c',
      'name' => 'documents_c',
      'label' => 'LBL_DOCUMENTS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 19:56:24',
      'deleted' => '0',
      'audited' => '1',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'documents_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsactivity_c' => 
    array (
      'id' => 'Accountsactivity_c',
      'name' => 'activity_c',
      'label' => 'LBL_ACTIVITY',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 19:57:43',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsschema_register_c' => 
    array (
      'id' => 'Accountsschema_register_c',
      'name' => 'schema_register_c',
      'label' => 'LBL_SCHEMA_REGISTER',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 20:00:49',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsbilling_address_colonia_c' => 
    array (
      'id' => 'Accountsbilling_address_colonia_c',
      'name' => 'billing_address_colonia_c',
      'label' => 'LBL_BILLING_ADDRESS_COLONIA',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '150',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 20:02:56',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsbilling_address_town_c' => 
    array (
      'id' => 'Accountsbilling_address_town_c',
      'name' => 'billing_address_town_c',
      'label' => 'LBL_BILLING_ADDRESS_TOWN',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 20:06:05',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsbilling_address_ou_c' => 
    array (
      'id' => 'Accountsbilling_address_ou_c',
      'name' => 'billing_address_ou_c',
      'label' => 'LBL_BILLING_ADDRESS_OU',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '20',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 20:08:59',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsbilling_address_in_c' => 
    array (
      'id' => 'Accountsbilling_address_in_c',
      'name' => 'billing_address_in_c',
      'label' => 'LBL_BILLING_ADDRESS_IN',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '20',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 20:09:29',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsstatus_c' => 
    array (
      'id' => 'Accountsstatus_c',
      'name' => 'status_c',
      'label' => 'LBL_STATUS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Active',
      'date_modified' => '2011-01-04 20:17:45',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'release_status_dom',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq1_c' => 
    array (
      'id' => 'Accountsq1_c',
      'name' => 'q1_c',
      'label' => 'LBL_Q1',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:09:27',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq2_c' => 
    array (
      'id' => 'Accountsq2_c',
      'name' => 'q2_c',
      'label' => 'LBL_Q2',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:12:24',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq3_c' => 
    array (
      'id' => 'Accountsq3_c',
      'name' => 'q3_c',
      'label' => 'LBL_Q3',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:09:40',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq4_c' => 
    array (
      'id' => 'Accountsq4_c',
      'name' => 'q4_c',
      'label' => 'LBL_Q4',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:09:46',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq5_c' => 
    array (
      'id' => 'Accountsq5_c',
      'name' => 'q5_c',
      'label' => 'LBL_Q5',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:09:54',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq6_c' => 
    array (
      'id' => 'Accountsq6_c',
      'name' => 'q6_c',
      'label' => 'LBL_Q6',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:10:01',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq7_c' => 
    array (
      'id' => 'Accountsq7_c',
      'name' => 'q7_c',
      'label' => 'LBL_Q7',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'undefined',
      'date_modified' => '2011-01-04 23:10:08',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'app_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq8_c' => 
    array (
      'id' => 'Accountsq8_c',
      'name' => 'q8_c',
      'label' => 'LBL_Q8',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:42:43',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq9_c' => 
    array (
      'id' => 'Accountsq9_c',
      'name' => 'q9_c',
      'label' => 'LBL_Q9',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 23:10:21',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq10_c' => 
    array (
      'id' => 'Accountsq10_c',
      'name' => 'q10_c',
      'label' => 'LBL_Q10',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'undefined',
      'date_modified' => '2011-01-04 22:47:50',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'app_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq11_c' => 
    array (
      'id' => 'Accountsq11_c',
      'name' => 'q11_c',
      'label' => 'LBL_Q11',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:48:34',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq12_c' => 
    array (
      'id' => 'Accountsq12_c',
      'name' => 'q12_c',
      'label' => 'LBL_Q12',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:49:45',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq13_c' => 
    array (
      'id' => 'Accountsq13_c',
      'name' => 'q13_c',
      'label' => 'LBL_Q13',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:50:52',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq14_c' => 
    array (
      'id' => 'Accountsq14_c',
      'name' => 'q14_c',
      'label' => 'LBL_Q14',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-04 22:51:36',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsq15_c' => 
    array (
      'id' => 'Accountsq15_c',
      'name' => 'q15_c',
      'label' => 'LBL_Q15',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'on',
      'date_modified' => '2011-01-04 22:52:30',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'dom_switch_bool',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Accountsdocs_attached_c' => 
    array (
      'id' => 'Accountsdocs_attached_c',
      'name' => 'docs_attached_c',
      'label' => 'LBL_DOCS_ATTACHED',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-05 01:23:28',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'docs_attached_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Contactsm_name_c' => 
    array (
      'id' => 'Contactsm_name_c',
      'name' => 'm_name_c',
      'label' => 'LBL_M_NAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Contacts',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-05 00:13:41',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Contactscurp_c' => 
    array (
      'id' => 'Contactscurp_c',
      'name' => 'curp_c',
      'label' => 'LBL_CURP',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Contacts',
      'type' => 'varchar',
      'max_size' => '18',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-05 00:15:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Opportunitiesfolio_package_c' => 
    array (
      'id' => 'Opportunitiesfolio_package_c',
      'name' => 'folio_package_c',
      'label' => 'LBL_FOLIO_PACKAGE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Opportunities',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'undefined',
      'date_modified' => '2011-01-05 18:47:09',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'folio_package_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Opportunitiesdeployment_c' => 
    array (
      'id' => 'Opportunitiesdeployment_c',
      'name' => 'deployment_c',
      'label' => 'LBL_DEPLOYMENT',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Opportunities',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-05 17:57:03',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'deployment_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Opportunitiesapp_type_c' => 
    array (
      'id' => 'Opportunitiesapp_type_c',
      'name' => 'app_type_c',
      'label' => 'LBL_APP_TYPE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Opportunities',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-01-05 18:11:14',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'app_type_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Accounts/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Accounts/metadata/detailviewdefs.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Accounts/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Accounts/metadata/detailviewdefs.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Accounts/metadata/editviewdefs.php',
      'to' => 'custom/modules/Accounts/metadata/editviewdefs.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Accounts/metadata/editviewdefs.php',
      'to' => 'custom/working/modules/Accounts/metadata/editviewdefs.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Contacts/metadata/detailviewdefs.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Contacts/metadata/detailviewdefs.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/metadata/editviewdefs.php',
      'to' => 'custom/modules/Contacts/metadata/editviewdefs.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/metadata/editviewdefs.php',
      'to' => 'custom/working/modules/Contacts/metadata/editviewdefs.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/detailviewdefs.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/detailviewdefs.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Opportunities/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Opportunities/metadata/detailviewdefs.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Opportunities/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Opportunities/metadata/detailviewdefs.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Opportunities/metadata/editviewdefs.php',
      'to' => 'custom/modules/Opportunities/metadata/editviewdefs.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Opportunities/metadata/editviewdefs.php',
      'to' => 'custom/working/modules/Opportunities/metadata/editviewdefs.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Prospects/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Prospects/metadata/detailviewdefs.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Prospects/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Prospects/metadata/detailviewdefs.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_activity_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_activity_c.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_city.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_city.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_colonia_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_colonia_c.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_in_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_in_c.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_ou_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_ou_c.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_town_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_billing_address_town_c.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_docs_attached_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_docs_attached_c.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_documents_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_documents_c.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_name.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_name.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q10_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q10_c.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q11_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q11_c.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q12_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q12_c.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q13_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q13_c.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q14_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q14_c.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q15_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q15_c.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q1_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q1_c.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q2_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q2_c.php',
    ),
    33 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q3_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q3_c.php',
    ),
    34 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q4_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q4_c.php',
    ),
    35 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q5_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q5_c.php',
    ),
    36 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q6_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q6_c.php',
    ),
    37 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q7_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q7_c.php',
    ),
    38 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q8_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q8_c.php',
    ),
    39 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q9_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_q9_c.php',
    ),
    40 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_rfc_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_rfc_c.php',
    ),
    41 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_schema_register_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_schema_register_c.php',
    ),
    42 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_status_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_status_c.php',
    ),
    43 => 
    array (
      'from' => '<basepath>/Extension/modules/Accounts/Ext/Vardefs/sugarfield_type_customer_c.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/sugarfield_type_customer_c.php',
    ),
    44 => 
    array (
      'from' => '<basepath>/Extension/modules/Contacts/Ext/Vardefs/sugarfield_curp_c.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/sugarfield_curp_c.php',
    ),
    45 => 
    array (
      'from' => '<basepath>/Extension/modules/Contacts/Ext/Vardefs/sugarfield_m_name_c.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/sugarfield_m_name_c.php',
    ),
    46 => 
    array (
      'from' => '<basepath>/Extension/modules/Documents/Ext/Vardefs/sugarfield_template_type.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Vardefs/sugarfield_template_type.php',
    ),
    47 => 
    array (
      'from' => '<basepath>/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_app_type_c.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_app_type_c.php',
    ),
    48 => 
    array (
      'from' => '<basepath>/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_deployment_c.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_deployment_c.php',
    ),
    49 => 
    array (
      'from' => '<basepath>/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_folio_package_c.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/Vardefs/sugarfield_folio_package_c.php',
    ),
  ),
);
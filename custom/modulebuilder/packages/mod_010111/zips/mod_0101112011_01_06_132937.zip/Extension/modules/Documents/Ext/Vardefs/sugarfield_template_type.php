<?php
 // created: 2011-01-05 10:11:24
$dictionary['Document']['fields']['template_type']['default']='undefined';
$dictionary['Document']['fields']['template_type']['options']='docs_attached_list';
$dictionary['Document']['fields']['template_type']['reportable']=true;

 ?>
<?php 
 // created: 2011-01-06 13:29:37
$mod_strings['LBL_TEMPLATE_TYPE'] = 'Tipo de Documento';

?>

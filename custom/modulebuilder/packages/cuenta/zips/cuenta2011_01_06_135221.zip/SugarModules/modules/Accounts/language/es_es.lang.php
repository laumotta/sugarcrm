<?php 
 // created: 2011-01-06 13:52:21
$mod_strings['LBL_TYPE_CUSTOMER'] = 'Tipo de contribuyente';
$mod_strings['LBL_RFC'] = 'RFC';
$mod_strings['LBL_DOCUMENTS'] = 'Emisión de documentos';
$mod_strings['LBL_ACTIVITY'] = 'Actividad preponderante';
$mod_strings['LBL_SCHEMA_REGISTER'] = 'Regimen fiscal registrado ante SAT';
$mod_strings['LBL_NAME'] = 'Razón social';
$mod_strings['LBL_BILLING_ADDRESS_COLONIA'] = 'Colonia:';
$mod_strings['LBL_BILLING_ADDRESS_CITY'] = 'Ciudad / localidad de facturación:';
$mod_strings['LBL_BILLING_ADDRESS_TOWN'] = 'Delegación / Municipio';
$mod_strings['LBL_BILLING_ADDRESS_OU'] = 'No. Exterior';
$mod_strings['LBL_BILLING_ADDRESS_IN'] = 'No. Interior';
$mod_strings['LBL_STATUS'] = 'Situación fiscal';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Cuestionario de perfilamiento';
$mod_strings['LBL_Q1'] = '¿Ya emite CFD?';
$mod_strings['LBL_Q2'] = '¿Medios propios o através de un PACFD?';
$mod_strings['LBL_Q3'] = '¿Cuenta con FIEL?';
$mod_strings['LBL_Q4'] = '¿Tiene al menos un certificado de sello digital?';
$mod_strings['LBL_Q5'] = '¿Tiene folios asignados por el SAT?';
$mod_strings['LBL_Q6'] = '¿Cuenta con un sistema electrónico contable?';
$mod_strings['LBL_Q7'] = '¿Es un programa comercial o diseñado a la medida?';
$mod_strings['LBL_Q8'] = 'Si es comercial indique cual';
$mod_strings['LBL_Q9'] = '¿Cuenta con sistema para administrar su facturación tradicional?';
$mod_strings['LBL_Q10'] = '¿Es un programa comercial o diseñado ala medida?';
$mod_strings['LBL_Q11'] = 'Si es comercial indique cual';
$mod_strings['LBL_Q12'] = '¿Cuenta con personal de sistemas en su empresa?';
$mod_strings['LBL_Q13'] = '¿Cuantos comprobantes emite mensualmente?';
$mod_strings['LBL_Q14'] = '¿Numero de sucursales?';
$mod_strings['LBL_Q15'] = '¿Emitirá series de folios por sucursal?';
$mod_strings['LBL_PANEL_ASSIGNMENT'] = 'Drircciones';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Cuestionario de perfilamiento';
$mod_strings['LBL_DOCS_ATTACHED'] = 'Documentación Adjuntada';

?>

<?php 
 // created: 2011-01-06 13:18:22
$mod_strings['LBL_M_NAME'] = 'Apellido materno';
$mod_strings['LBL_CURP'] = 'CURP';
$mod_strings['LBL_LAST_NAME'] = 'Apellido paterno';

?>

<?php 
 // created: 2011-01-06 13:18:23
$mod_strings['LBL_FOLIO_PACKAGE'] = 'Paquetes de folios';
$mod_strings['LBL_DEPLOYMENT'] = 'Desarrollos';
$mod_strings['LBL_APP_TYPE'] = 'Aplicación';

?>

<?php
$viewdefs ['Accounts'] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'SAVE',
          1 => 'CANCEL',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Accounts/Account.js',
        ),
      ),
      'useTabs' => true,
    ),
    'panels' => 
    array (
      'lbl_account_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
            'displayParams' => 
            array (
              'required' => true,
            ),
          ),
          1 => 
          array (
            'name' => 'rfc_c',
            'label' => 'LBL_RFC',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'type_customer_c',
            'studio' => 'visible',
            'label' => 'LBL_TYPE_CUSTOMER',
          ),
          1 => 
          array (
            'name' => 'phone_office',
            'label' => 'LBL_PHONE_OFFICE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'schema_register_c',
            'label' => 'LBL_SCHEMA_REGISTER',
          ),
          1 => 
          array (
            'name' => 'phone_fax',
            'label' => 'LBL_PHONE_FAX',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'activity_c',
            'label' => 'LBL_ACTIVITY',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'docs_attached_c',
            'studio' => 'visible',
            'label' => 'LBL_DOCS_ATTACHED',
          ),
          1 => 
          array (
            'name' => 'documents_c',
            'studio' => 'visible',
            'label' => 'LBL_DOCUMENTS',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'email1',
            'studio' => 'false',
            'label' => 'LBL_EMAIL',
          ),
          1 => 
          array (
            'name' => 'website',
            'type' => 'link',
            'label' => 'LBL_WEBSITE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'status_c',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
          ),
          1 => 
          array (
            'name' => 'q1_c',
            'studio' => 'visible',
            'label' => 'LBL_Q1',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'q2_c',
            'label' => 'LBL_Q2',
          ),
          1 => 
          array (
            'name' => 'q3_c',
            'studio' => 'visible',
            'label' => 'LBL_Q3',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'q4_c',
            'studio' => 'visible',
            'label' => 'LBL_Q4',
          ),
          1 => 
          array (
            'name' => 'q5_c',
            'studio' => 'visible',
            'label' => 'LBL_Q5',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'q6_c',
            'studio' => 'visible',
            'label' => 'LBL_Q6',
          ),
          1 => 
          array (
            'name' => 'q7_c',
            'studio' => 'visible',
            'label' => 'LBL_Q7',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'q8_c',
            'label' => 'LBL_Q8',
          ),
          1 => '',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'q9_c',
            'studio' => 'visible',
            'label' => 'LBL_Q9',
          ),
          1 => 
          array (
            'name' => 'q10_c',
            'studio' => 'visible',
            'label' => 'LBL_Q10',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'q11_c',
            'label' => 'LBL_Q11',
          ),
          1 => '',
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'q12_c',
            'studio' => 'visible',
            'label' => 'LBL_Q12',
          ),
          1 => 
          array (
            'name' => 'q13_c',
            'label' => 'LBL_Q13',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'q14_c',
            'label' => 'LBL_Q14',
          ),
          1 => 
          array (
            'name' => 'q15_c',
            'studio' => 'visible',
            'label' => 'LBL_Q15',
          ),
        ),
      ),
      'LBL_PANEL_ASSIGNMENT' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'billing',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
          1 => 
          array (
            'name' => 'shipping_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'shipping',
              'copy' => 'billing',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_town_c',
            'label' => 'LBL_BILLING_ADDRESS_TOWN',
          ),
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_ou_c',
            'label' => 'LBL_BILLING_ADDRESS_OU',
          ),
          1 => '',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_in_c',
            'label' => 'LBL_BILLING_ADDRESS_IN',
          ),
          1 => '',
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_colonia_c',
            'label' => 'LBL_BILLING_ADDRESS_COLONIA',
          ),
          1 => '',
        ),
      ),
      'LBL_PANEL_ADVANCED' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'account_type',
            'comment' => 'The Company is of this type',
            'label' => 'LBL_TYPE',
          ),
          1 => 
          array (
            'name' => 'industry',
            'comment' => 'The company belongs in this industry',
            'label' => 'LBL_INDUSTRY',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'parent_name',
            'label' => 'LBL_MEMBER_OF',
          ),
          1 => 
          array (
            'name' => 'ownership',
            'comment' => '',
            'label' => 'LBL_OWNERSHIP',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'campaign_name',
            'comment' => 'The first campaign name for Account (Meta-data only)',
            'label' => 'LBL_CAMPAIGN',
          ),
          1 => 
          array (
            'name' => 'rating',
            'comment' => 'An arbitrary rating for this company for use in comparisons with others',
            'label' => 'LBL_RATING',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
